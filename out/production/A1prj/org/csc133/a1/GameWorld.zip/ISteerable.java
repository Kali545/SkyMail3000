package org.csc133.a1;

public interface ISteerable {
    void steer (int heading, int degree); //this will change the heading by

}

