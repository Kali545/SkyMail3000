package org.csc133.a1;

public class SkyScraper extends GameObject {
    private int sequenceNumber;
    public SkyScraper(){
        super();
        sequenceNumber = 0;
    }
    public SkyScraper(int size, int shape, int myColor, double X, double Y){
    super(size,shape,myColor,X,Y);
    this.sequenceNumber = sequenceNumber;

    }


}
